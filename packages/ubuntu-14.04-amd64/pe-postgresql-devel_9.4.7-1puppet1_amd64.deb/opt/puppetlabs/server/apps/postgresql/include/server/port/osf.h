/* src/include/port/osf.h */

#define NOFIXADE
#define DISABLE_XOPEN_NLS
