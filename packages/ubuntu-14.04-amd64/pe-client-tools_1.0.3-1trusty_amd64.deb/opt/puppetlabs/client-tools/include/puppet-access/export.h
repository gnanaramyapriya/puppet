
#ifndef LIBPUPPET_ACCESS_EXPORT_H
#define LIBPUPPET_ACCESS_EXPORT_H

#ifdef LIBPUPPET_ACCESS_STATIC_DEFINE
#  define LIBPUPPET_ACCESS_EXPORT
#  define LIBPUPPET_ACCESS_NO_EXPORT
#else
#  ifndef LIBPUPPET_ACCESS_EXPORT
#    ifdef libpuppet_access_EXPORTS
        /* We are building this library */
#      define LIBPUPPET_ACCESS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define LIBPUPPET_ACCESS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef LIBPUPPET_ACCESS_NO_EXPORT
#    define LIBPUPPET_ACCESS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef LIBPUPPET_ACCESS_DEPRECATED
#  define LIBPUPPET_ACCESS_DEPRECATED 
#endif

#ifndef LIBPUPPET_ACCESS_DEPRECATED_EXPORT
#  define LIBPUPPET_ACCESS_DEPRECATED_EXPORT LIBPUPPET_ACCESS_EXPORT LIBPUPPET_ACCESS_DEPRECATED
#endif

#ifndef LIBPUPPET_ACCESS_DEPRECATED_NO_EXPORT
#  define LIBPUPPET_ACCESS_DEPRECATED_NO_EXPORT LIBPUPPET_ACCESS_NO_EXPORT LIBPUPPET_ACCESS_DEPRECATED
#endif

#define DEFINE_NO_DEPRECATED 0
#if DEFINE_NO_DEPRECATED
# define LIBPUPPET_ACCESS_NO_DEPRECATED
#endif

#endif
