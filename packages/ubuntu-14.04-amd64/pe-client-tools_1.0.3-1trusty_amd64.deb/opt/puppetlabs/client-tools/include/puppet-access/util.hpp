#pragma once

#include "export.h"
#include <string>

namespace puppet_access { namespace util {

std::string LIBPUPPET_ACCESS_EXPORT base64_decode(const std::string& b64_data);

}
}
