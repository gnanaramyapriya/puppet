///
/// @file
/// Declares macros for the puppet-access library version.
///
#pragma once

///
/// The puppet-access library major version.
///
#define PUPPET_ACCESS_VERSION_MAJOR 1
///
/// The puppet-access library minor version.
///
#define PUPPET_ACCESS_VERSION_MINOR 0
///
/// The puppet-access library patch version.
///
#define PUPPET_ACCESS_VERSION_PATCH 0

///
/// The puppet-access library version as a string (without commit SHA1).
///
#define PUPPET_ACCESS_VERSION "1.0.0"

///
/// The puppet-access library version as a string (with commit SHA1).
///
#define PUPPET_ACCESS_VERSION_WITH_COMMIT "1.0.0"
