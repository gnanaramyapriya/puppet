#pragma once

#include <boost/filesystem.hpp>

namespace puppet_access {

void write_file_securely(const std::string& text, const boost::filesystem::path& file_path);

std::string read_file(const boost::filesystem::path& path);

void delete_file(const boost::filesystem::path& path);

}
