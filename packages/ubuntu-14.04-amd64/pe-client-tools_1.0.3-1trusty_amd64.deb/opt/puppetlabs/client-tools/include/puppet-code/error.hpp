#pragma once
#include <stdexcept>

namespace puppet_code {

/// Exception class for errors encountered while reading/loading config files.
struct config_error : std::runtime_error {
    config_error(const char *what_arg) : runtime_error(what_arg) {}
    config_error(const std::string &what_arg) : runtime_error(what_arg) {}
};

}; // namespace puppet_code
