#pragma once

#include <string>
#include "export.h"

#include <boost/filesystem.hpp>

// boost includes are not always warning-clean. Disable warnings that
// cause problems before including the headers, then re-enable the warnings.
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wattributes"
#include <boost/program_options.hpp>
#pragma GCC diagnostic pop

namespace puppet_code { namespace config {

    namespace fs = boost::filesystem;

    struct LIBPUPPET_CODE_EXPORT Config {
        boost::filesystem::path token_file;
        boost::filesystem::path certificate_file;
        std::string service_url;

        std::string pretty_print() const;

        std::string token() const;

        /**
         * Update this config object in place with values set in the provided Config object.
         */
        void update(const Config &other);
    };

    Config LIBPUPPET_CODE_EXPORT default_config();

    /**
     * Merge config file sources, depending on what files are present and what CLI
     * options were passed.
     *
     * With the config-file CLI option:
     *
     *  1. Defaults
     *  2. config-file
     *  3. CLI options
     *
     * With no config-file CLI option:
     *
     *  1. Defaults
     *  2. Global config file (if present)
     *  3. User config file (if present)
     *  4. CLI options
     *
     * @return The fully merged config object.
     */
    Config LIBPUPPET_CODE_EXPORT full_config(const boost::program_options::variables_map &vm);

    Config LIBPUPPET_CODE_EXPORT config_from_cli(const boost::program_options::variables_map &vm);

    Config LIBPUPPET_CODE_EXPORT config_from_file(const boost::filesystem::path & path);

    Config LIBPUPPET_CODE_EXPORT parse_config(const std::string & json_body);

    boost::filesystem::path LIBPUPPET_CODE_EXPORT default_token_file();
    boost::filesystem::path LIBPUPPET_CODE_EXPORT default_certificate_file();
    std::string default_service_url();

    boost::filesystem::path LIBPUPPET_CODE_EXPORT global_config();
    boost::filesystem::path LIBPUPPET_CODE_EXPORT user_config();
}
}
