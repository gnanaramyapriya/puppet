
#ifndef LIBPUPPET_CODE_EXPORT_H
#define LIBPUPPET_CODE_EXPORT_H

#ifdef LIBPUPPET_CODE_STATIC_DEFINE
#  define LIBPUPPET_CODE_EXPORT
#  define LIBPUPPET_CODE_NO_EXPORT
#else
#  ifndef LIBPUPPET_CODE_EXPORT
#    ifdef libpuppet_code_EXPORTS
        /* We are building this library */
#      define LIBPUPPET_CODE_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define LIBPUPPET_CODE_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef LIBPUPPET_CODE_NO_EXPORT
#    define LIBPUPPET_CODE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef LIBPUPPET_CODE_DEPRECATED
#  define LIBPUPPET_CODE_DEPRECATED 
#endif

#ifndef LIBPUPPET_CODE_DEPRECATED_EXPORT
#  define LIBPUPPET_CODE_DEPRECATED_EXPORT LIBPUPPET_CODE_EXPORT LIBPUPPET_CODE_DEPRECATED
#endif

#ifndef LIBPUPPET_CODE_DEPRECATED_NO_EXPORT
#  define LIBPUPPET_CODE_DEPRECATED_NO_EXPORT LIBPUPPET_CODE_NO_EXPORT LIBPUPPET_CODE_DEPRECATED
#endif

#define DEFINE_NO_DEPRECATED 0
#if DEFINE_NO_DEPRECATED
# define LIBPUPPET_CODE_NO_DEPRECATED
#endif

#endif
