///
/// @file
/// Declares macros for the puppet-code library version.
///
#pragma once

///
/// The puppet-code library major version.
///
#define PUPPET_CODE_VERSION_MAJOR 0
///
/// The puppet-code library minor version.
///
#define PUPPET_CODE_VERSION_MINOR 1
///
/// The puppet-code library patch version.
///
#define PUPPET_CODE_VERSION_PATCH 0

///
/// The puppet-code library version as a string (without commit SHA1).
///
#define PUPPET_CODE_VERSION "0.1.0"

///
/// The puppet-code library version as a string (with commit SHA1).
///
#define PUPPET_CODE_VERSION_WITH_COMMIT "0.1.0 (commit 9caf577c432f50830341215aab29dc490909981e)"
