#pragma once

#include <leatherman/curl/client.hpp>
#include <leatherman/curl/request.hpp>
#include <leatherman/json_container/json_container.hpp>

#include "export.h"
#include <puppet-code/config.hpp>

#include <boost/filesystem.hpp>

#include <stdexcept>

namespace puppet_code {
namespace api_client {
using leatherman::json_container::JsonContainer;
namespace json = leatherman::json_container;

// TODO: can leatherman's enum be public?
enum http_method {
    post,
    get,
};

// Struct for errors in the pe format.
// TODO: needs to be moved somewhere more general and handled
struct pe_error : std::runtime_error {
    public:
        const std::string kind;
        pe_error(const std::string &kind, const std::string &what_arg) : runtime_error(what_arg), kind(kind) {};
};

// Errors connecting to code-manager, getting a 2xx response or parsing the
// standard body.  This means we'll have to create types and messages for
// things that don't come from code-manager proper. This may be a mistake but
// it may allow for easier error display.
struct LIBPUPPET_CODE_EXPORT client_error : pe_error {
    public:
        client_error(const std::string &kind, const std::string &what_arg) : pe_error(kind, what_arg) {};
        client_error(JsonContainer error);
};

// Handle errors in a successfully queued deploy. I don't know if these will even be error objects.
struct LIBPUPPET_CODE_EXPORT deploy_error : pe_error {
    public:
        deploy_error(const std::string &kind, const std::string &message): pe_error(kind, message) {};
};

#include <iostream>

struct LIBPUPPET_CODE_EXPORT deploy_result {
    public:
        int status_code;
        JsonContainer body;

        bool ok() {

            if (status_code != 200) {
                return false;
            } else {
                bool rv = true;
                for(size_t i = 0; i < body.size(); ++i) {
                    json::JsonContainer j = body.get<json::JsonContainer>(i);
                    if (j.includes("status")) {
                        rv &= j.get<std::string>("status") != "failed";
                    }
                }
                return rv;
            }
        }
};

class LIBPUPPET_CODE_EXPORT APIClient {
    private:
        boost::filesystem::path certificate_file;
        std::string token;
        std::string service_url;
        leatherman::curl::client client;

        // Build a curl client using the instances config values.
        LIBPUPPET_CODE_NO_EXPORT leatherman::curl::client get_client();

        // Build a request from a relative path and a jsoncontainer of the body
        LIBPUPPET_CODE_NO_EXPORT leatherman::curl::request build_request(const std::string &path, const JsonContainer &body);

    public:

        // Use a code-manager config to set up the client.
        APIClient(const puppet_code::config::Config &config) :
            APIClient(
                    config.certificate_file,
                    config.token(),
                    config.service_url) {};


        // Empty constuctor for testing. may hide errors.
        APIClient(const boost::filesystem::path certificate_file, const std::string token, const std::string service_url) :
            certificate_file(certificate_file),
            token(token),
            service_url(service_url) {
                client.set_ca_cert(certificate_file.string());
            };

        // Check a response for errors and parse the json body.
        // Any standardized error handling across endpoints should go here.
        deploy_result process_response(const leatherman::curl::response response);

        // We should probably make the method enum public and collapse these.
        deploy_result make_request(const http_method method, const std::string &path, const JsonContainer &body);

        // Make a request to dpeloy a single environment and return any information.
        // about it.
        deploy_result deploy_environment(const std::string &environment, const bool wait=false);

        // TODO: Make a request to deploy all environments.
        deploy_result deploy_all(const bool wait=false);

        // TODO: Check status of the code-manager server.
        JsonContainer health_status();

        // Get the User-Agent header for this client.
        std::string user_agent();
};
}  // api_client
}  // namespace puppet_code
