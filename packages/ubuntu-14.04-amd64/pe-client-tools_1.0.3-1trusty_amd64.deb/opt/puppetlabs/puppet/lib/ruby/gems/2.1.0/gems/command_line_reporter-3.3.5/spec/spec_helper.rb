$: << File.join(File.dirname(__FILE__), '..', 'lib')

require 'command_line_reporter'

require_relative 'support/helpers/stdout'
require_relative 'support/matchers/argument'
