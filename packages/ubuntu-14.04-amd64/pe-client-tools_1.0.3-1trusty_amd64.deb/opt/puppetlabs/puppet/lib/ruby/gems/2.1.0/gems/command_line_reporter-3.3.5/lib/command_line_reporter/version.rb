module CommandLineReporter
  VERSION = '3.3.5'
end
