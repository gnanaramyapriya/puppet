require_relative 'razor/cli'
