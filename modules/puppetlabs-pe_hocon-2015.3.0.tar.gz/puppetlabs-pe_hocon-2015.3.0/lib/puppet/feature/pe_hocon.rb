require 'puppet/util/feature'

Puppet.features.add(:pe_hocon, :libs => ['hocon'])

