require 'spec_helper'
require 'erb'

RSpec.shared_examples("repo behavior") do |platform|
  deprecated_platform_regex = /^ubuntu-15\.04|^debian-6|^fedora-21/
  if platform =~ deprecated_platform_regex
    context "on deprecated platform" do
      it "emits a warning" do
        should contain_notify("#{platform} deprecation warning")
          .with_loglevel("warning")
      end
    end
  else
    context "on *nix", :if => platform !~ /^windows/ do
      it "creates a pe_repo::repo resource" do
        should contain_pe_repo__repo("#{platform_name} #{pe_build_version}")
          .with_agent_version(agent_version)
          .with_installer_build(platform_name)
          .with_pe_version(pe_build_version)
      end

      it "creates a pe_staging::deploy resource" do
        tarball_name = case platform_name
        when /osx/ then "puppet-agent-osx-#{platform_name.split('-')[1]}.tar.gz"
        else "puppet-agent-#{platform_name}.tar.gz"
        end

        should contain_pe_staging__deploy(tarball_name)
          .with_source("https://pm.puppetlabs.com/puppet-agent/#{pe_build_version}/#{agent_version}/repos/#{tarball_name}")
          .with_target("/opt/puppetlabs/server/data/packages/public/#{pe_build_version}/#{platform_name}-#{agent_version}")
      end
    end

    context "on windows", :if => platform =~ /^windows/ do
      let(:arch) { platform_name.split('-')[1] == 'i386' ? 'x86' : 'x64' }

      it "creates a pe_staging::file directly" do
        msi = "puppet-agent-#{arch}.msi"
        should contain_pe_staging__file(msi)
          .with_source("https://pm.puppetlabs.com/puppet-agent/#{pe_build_version}/#{agent_version}/repos/windows/#{msi}")
          .with_target("/opt/puppetlabs/server/data/packages/public/#{pe_build_version}/#{platform_name}-#{agent_version}/#{msi}")
      end
    end
  end
end

platform_manifests_path = File.join(File.dirname(__FILE__), "../../manifests/platform/*")
Dir.glob(platform_manifests_path).map do |file|
  File.basename(file).split('.')[0]
end.each do |platform_class|
  # The platform string as produced by the puppet_enterprise module's platform_tag
  # fact is in a different format than the simpler platform filenames, and we need
  # to perform some munging here.  The format is a by product of the various us name,
  # version, architecture facts.
  platform = platform_class.gsub('_','-').gsub('x86-64', 'x86_64')
  platform =  case platform
    when /aix-(\d)(\d)-(.*)/ then "aix-#{$1}.#{$2}-#{$3}"
    when /ubuntu-(\d{2})(\d{2})-(.*)/ then "ubuntu-#{$1}.#{$2}-#{$3}"
    when /osx-(\d{2})(\d+)-(.*)/ then "osx-#{$1}.#{$2}-#{$3}"
    else platform
  end

  RSpec.describe "pe_repo::platform::#{platform_class}" do
    let(:platform_name) { platform }
    let(:agent_version) { '1.2.2' }
    let(:params) do
      {
        :agent_version => agent_version
      }
    end

    it "compiles" do
      should compile.with_all_deps
    end

    context "with pe_build fact" do
      let(:pe_build_version) { '2015.2.0' }
      let(:facts) do
        {
          :pe_build => pe_build_version,
        }
      end

      include_examples("repo behavior", platform)
    end

    context "without pe_build fact" do
      # Mystery: Not specifying a nil pe_build causes the mock function not to be executed...?
      let(:facts) do
        {
          :pe_build => nil,
        }
      end
      let(:pe_build_version) { '2015.2.1' }

      before(:example) do
        mock_pe_build_version = double(:call => pe_build_version)
        Puppet::Parser::Functions.newfunction(:pe_build_version, :type => :rvalue) do |args|
          mock_pe_build_version.call()
        end
      end

      include_examples("repo behavior", platform)
    end

    context "supported_platforms" do
      it 'contains all platforms supported by the frictionless bash installer' do
        file_path = File.join(File.dirname(__FILE__), '../../templates/partials/shared_functions.bash.erb')
        shared_functions = ERB.new(File.read(file_path))
        unless platform =~ /windows/
          expect(
            system("bash", "-c", %Q{
                 #{shared_functions.result}
                supported_platform "#{platform}"
            })
          ).to be true
        end
      end
    end
  end

  context "unsupported platform" do
    it 'fails when given an unsupported platform' do
      file_path = File.join(File.dirname(__FILE__), '../../templates/partials/shared_functions.bash.erb')
      shared_functions = ERB.new(File.read(file_path))
      expect(
        system("bash", "-c", %Q{
             #{shared_functions.result}
            supported_platform "unicornOS"
        })
      ).to be false
    end
  end
end
