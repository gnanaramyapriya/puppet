#! /usr/bin/env ruby -S rspec
require 'spec_helper'

describe "the pe_servername function" do
  let(:scope) { PuppetlabsSpec::PuppetInternals.scope }

  it "should exist" do
    expect(Puppet::Parser::Functions.function("pe_servername")).to eq("function_pe_servername")
  end

  it "should raise a ParseError if there are arguments" do
    expect { scope.function_pe_servername(['1']) }.to( raise_error(Puppet::ParseError) )
  end

  it "should return nil if servername is unset" do
    result = scope.function_pe_servername([])
    expect(result).to(eq(nil))
  end

  context "servername is set" do
    servername = 'foobar'
    before(:each) {
      scope.expects(:exist?).with('servername').returns(true)
      scope.expects(:lookupvar).with('servername').returns(servername)
    }

    it "should return servername" do
      result = scope.function_pe_servername([])
      expect(result).to(eq(servername))
    end
  end
end
