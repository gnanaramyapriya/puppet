#! /usr/bin/env ruby -S rspec
require 'spec_helper'

describe "the pe_compile_master function" do
  let(:scope) { PuppetlabsSpec::PuppetInternals.scope }
  before(:each) {
  }

  it "should exist" do
    expect(Puppet::Parser::Functions.function("pe_compile_master")).to eq("function_pe_compile_master")
  end

  it "should raise a ParseError if there are arguments" do
    expect { scope.function_pe_compile_master(['1']) }.to( raise_error(Puppet::ParseError) )
  end

  context "with servername/fqdn mocked" do
    let(:fqdn) { nil }
    let(:servername) { nil }

    before(:each) {
      scope.expects(:function_pe_servername).with([]).returns(servername)
      scope.expects(:lookupvar).with('fqdn').returns(fqdn)
    }

    context "servername unset, fqdn set" do
      let(:fqdn) { 'foobar' }
      let(:servername) { nil }

      it "should return true" do
        result = scope.function_pe_compile_master([])
        expect(result).to(eq(false))
      end
    end

    context "servername is the same as fqdn" do
      let(:fqdn) { 'foobar' }
      let(:servername) { 'foobar' }

      it "should return false" do
        result = scope.function_pe_compile_master([])
        expect(result).to(eq(false))
      end
    end

    context "servername is different from fqdn" do
      let(:fqdn) { 'foobar' }
      let(:servername) { 'bazbaz' }

      it "should return false" do
        result = scope.function_pe_compile_master([])
        expect(result).to(eq(true))
      end
    end

    context "servername is set, fqdn unset" do
      let(:fqdn) { nil }
      let(:servername) { 'bazbaz' }

      it "should raise a ParseError" do
        result = scope.function_pe_compile_master([])
        expect(result).to raise_error(Puppet::ParseError)
      end
    end
  end
end
