require 'spec_helper'

describe 'puppet_enterprise::puppetdb::sync_ini' do
  require 'puppet/resource/catalog'
  require 'puppet/indirector/memory'
  class ::Puppet::Resource::Catalog::StoreConfigsTesting < Puppet::Indirector::Memory; end

  before :all do
    @facter_facts = {
      'osfamily'          => 'Debian',
      'operatingsystem'   => 'Debian',
      'lsbmajdistrelease' => '6',
      'puppetversion'     => '3.6.2 (Puppet Enterprise 3.3.0)',
      'is_pe'             => 'true',
      'fqdn'              => 'master.rspec',
      'clientcert'        => 'awesomecert',
      'pe_concat_basedir' => '/tmp/file',
      'processorcount'    => '1',
      'servername'        => 'master.rspec',
      'pe_server_version' => '2015.3.0',
    }
    @params = {
      'certname' => 'awesomecert',
    }
  end

  let(:facts) { @facter_facts }
  let(:params) { @params }

  context 'managing files' do
    it { should contain_class('puppet_enterprise::puppetdb::sync_ini') }
    it { should contain_file('/etc/puppetlabs/puppetdb/conf.d/sync.ini') }
  end

  context 'when using default values' do
    before :each do
      Puppet::Parser::Functions.newfunction(:puppetdb_query,
                                            :type => :rvalue,
                                            :arity => 1) do |args|
        [{'certname' => 'puppetdb 9', 'parameters' => {'ssl_listen_port' => '8888'}},
         {'certname' => 'puppetdb 1', 'parameters' => {'ssl_listen_port' => '9999'}}]
      end

    end

    context 'when running in a `puppet agent -t` mode' do
      let(:node) { 'puppetdb.storeconfigstrue.test' }

      before :each do
        Puppet.settings[:storeconfigs] = true
        Puppet.settings[:storeconfigs_backend] = 'store_configs_testing'
      end

      it { should contain_pe_ini_setting('puppetdb_sync_server_urls').
                   with('ensure' => 'present',
                        'path' => '/etc/puppetlabs/puppetdb/conf.d/sync.ini',
                        'section' => 'sync',
                        'value' => 'https://puppetdb 1:9999,https://puppetdb 9:8888',
                        'setting' => 'server_urls')}
      it { should contain_pe_ini_setting('puppetdb_sync_intervals').
                   with('ensure'  => 'present',
                        'path'    => '/etc/puppetlabs/puppetdb/conf.d/sync.ini',
                        'section' => 'sync',
                        'setting' => 'intervals',
                        'value'   => '2m,2m')}
    end

    context 'when running with a `puppet apply` (i.e. on install)' do
      # rspec-puppet caches catalogs based on node name, manifest, facts and hiera config.
      # The settings are not part of this cache index, so catalogs which differ only by
      # Puppet.settings changes will end up returning the same catalog from rspec-puppet,
      # hence the need to change node name for some of these tests.
      let(:node) { 'puppetdb.storeconfigsfalse.test' }

      before :each do
        Puppet[:storeconfigs] = false
      end

      it { should contain_pe_ini_setting('puppetdb_sync_server_urls').
                   with(
                     'ensure'  => 'absent',
                     'section' => 'sync',
                     'setting' => 'server_urls',
                   )}
      it { should contain_pe_ini_setting('puppetdb_sync_intervals').
                   with(
                     'ensure'  => 'absent',
                     'section' => 'sync',
                     'setting' => 'intervals',
                   )}
    end
  end
end
