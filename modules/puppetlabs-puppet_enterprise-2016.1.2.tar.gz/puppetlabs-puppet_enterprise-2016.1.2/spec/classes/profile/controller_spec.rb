require 'spec_helper'

describe 'puppet_enterprise::profile::controller' do
  it { should contain_package("pe-client-tools") }

  [
    "/etc/puppetlabs/client-tools",
    "/etc/puppetlabs/client-tools/ssl",
    "/etc/puppetlabs/client-tools/ssl/certs"
  ].each do |path|
    it { should contain_file(path)
         .with_ensure('directory')
         .with_owner('root')
         .with_group('root')
         .with_mode('0755')
         .with_recurse(false) }
  end

  it { should contain_file("/etc/puppetlabs/client-tools/ssl/certs/ca.pem")
         .with_ensure('present')
         .with_owner('root')
         .with_group('root')
         .with_mode('0444')
         .with_source("/etc/puppetlabs/puppet/ssl/certs/ca.pem") }

  describe "puppet-code" do
    describe "when manage_puppet_code is false" do
      let(:params) { {"manage_puppet_code" => false} }
      it { should_not contain_file("/etc/puppetlabs/client-tools/puppet-code.conf") }
    end

    describe "when manage_puppet_code is true" do
      let(:params) { {"manage_puppet_code" => true} }
      it { should contain_file("/etc/puppetlabs/client-tools/puppet-code.conf")
           .with_ensure('present')
           .with_owner('root')
           .with_group('root')
           .with_mode('0444') }

      it "defaults the service URL to the CA server for puppet-code" do
        raw = catalogue.resource('file', '/etc/puppetlabs/client-tools/puppet-code.conf')[:content]
        json = JSON.parse(raw)
        expect(json['service-url']).to eq("https://master.rspec:8170/code-manager")
      end
    end
  end

  describe "orchestrator" do
    describe "when manage_orchestrator is false" do
      let(:params) { {"manage_orchestrator" => false} }
      it { should_not contain_file("/etc/puppetlabs/client-tools/orchestrator.conf") }
    end

    describe "when manage_orchestrator is true" do
      let(:params) { {"manage_orchestrator" => true} }
      it { should contain_file("/etc/puppetlabs/client-tools/orchestrator.conf")
           .with_ensure('present')
           .with_owner('root')
           .with_group('root')
           .with_mode('0444') }

      it "defaults the service URL to the CA server for orchestrator" do
        raw = catalogue.resource('file', '/etc/puppetlabs/client-tools/orchestrator.conf')[:content]
        json = JSON.parse(raw)
        expect(json['options']['service-url']).to eq("https://master.rspec:8143")
      end
    end
  end

  it { should satisfy_all_relationships }
end
