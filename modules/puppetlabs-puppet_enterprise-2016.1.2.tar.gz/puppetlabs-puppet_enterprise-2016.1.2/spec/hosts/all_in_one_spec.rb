require 'spec_helper'

describe 'all_in_one', :type => :host do
  before :each do
    Puppet::Parser::Functions.newfunction(:pe_compiling_server_aio_build, :type => :rvalue) do |args|
      nil
    end
  end
  let(:pre_condition) {}

  it { should satisfy_all_relationships }
end
